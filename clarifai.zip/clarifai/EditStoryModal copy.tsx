import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

type Story = {
  usid: string;
  title: string;
  role: string;
  story: string;
  acceptanceCriteria: string[];
  tshirt_size: string;
  priority: string;
  confidence?: number;
};

interface EditStoryModalProps {
  story: Story;
  onClose: () => void;
  onSave: (updatedStory: Story) => void;
}

export default function EditStoryModal({
  story,
  onClose,
  onSave,
}: EditStoryModalProps) {
  const [editedStory, setEditedStory] = useState<Story>(story);

  useEffect(() => {
    setEditedStory(story);
  }, [story]);

  const handleChange = (field: keyof Story, value: string | string[]) => {
    setEditedStory((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 text-white max-w-3xl w-full max-h-[90vh] overflow-y-auto rounded-lg">
        <DialogHeader>
          <DialogTitle>Edit User Story</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Read-only USID */}
          <div>
            <label className="text-sm text-gray-400 block mb-1">User Story ID</label>
            <input
              type="text"
              value={editedStory.usid}
              disabled
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-gray-400 cursor-not-allowed"
            />
          </div>

          {/* Read-only Confidence */}
          {editedStory.confidence !== undefined && (
            <div>
              <label className="text-sm text-gray-400 block mb-1">Confidence Score</label>
              <input
                type="text"
                value={editedStory.confidence.toString()}
                disabled
                className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-gray-400 cursor-not-allowed"
              />
            </div>
          )}

          {/* Editable Title */}
          <div>
            <label className="text-sm text-gray-400 block mb-1">Title</label>
            <input
              type="text"
              value={editedStory.title}
              onChange={(e) => handleChange("title", e.target.value)}
              placeholder="Title"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Editable Story */}
          <div>
            <label className="text-sm text-gray-400 block mb-1">User Story</label>
            <textarea
              value={editedStory.story}
              onChange={(e) => handleChange("story", e.target.value)}
              placeholder="User Story"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white h-24 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Editable Acceptance Criteria */}
          <div>
            <label className="text-sm text-gray-400 block mb-1">Acceptance Criteria</label>
            <textarea
              value={editedStory.acceptanceCriteria.join("\n")}
              onChange={(e) =>
                handleChange("acceptanceCriteria", e.target.value.split("\n"))
              }
              placeholder="Acceptance Criteria (one per line)"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white h-32 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Editable Priority */}
          <div>
            <label className="text-sm text-gray-400 block mb-1">Priority</label>
            <input
              type="text"
              value={editedStory.priority}
              onChange={(e) => handleChange("priority", e.target.value)}
              placeholder="Priority"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Editable T-Shirt Size */}
          <div>
            <label className="text-sm text-gray-400 block mb-1">T-Shirt Size</label>
            <input
              type="text"
              value={editedStory.tshirt_size}
              onChange={(e) => handleChange("tshirt_size", e.target.value)}
              placeholder="T-Shirt Size"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Editable Role */}
          <div>
            <label className="text-sm text-gray-400 block mb-1">Role</label>
            <input
              type="text"
              value={editedStory.role}
              onChange={(e) => handleChange("role", e.target.value)}
              placeholder="Role"
              className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <DialogFooter className="mt-4">
          <Button onClick={() => onSave(editedStory)}>Save</Button>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
